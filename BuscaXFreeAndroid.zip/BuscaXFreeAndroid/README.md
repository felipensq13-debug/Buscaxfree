# BuscaX Free — protótipo Android

Este é um protótipo inicial em Kotlin + Jetpack Compose.

## O que funciona
- Seleção de uma imagem da galeria usando o seletor de arquivos do Android.
- Botões para abrir Google Lens e Yandex Images.
- Atalhos para buscas web por páginas públicas de Instagram e TikTok.
- Aviso de privacidade e limitações.

## Limitação importante
O app não faz reconhecimento facial nem encontra automaticamente a conta de uma pessoa a partir do rosto. Os serviços externos abrem no navegador e o usuário precisa fazer a busca por lá. Não há API pública gratuita que garanta a busca de qualquer perfil do Instagram/TikTok por foto.

## Como abrir
1. Instale o Android Studio.
2. Abra a pasta `BuscaXFreeAndroid`.
3. Aguarde a sincronização do Gradle.
4. Execute em um emulador ou aparelho Android.

## Próximas etapas
Para ter busca reversa integrada de verdade, seria necessário selecionar um provedor com API, revisar os termos de uso, custos/limites e implementar o envio consentido da imagem. Este protótipo não envia a imagem automaticamente para nenhum serviço.
