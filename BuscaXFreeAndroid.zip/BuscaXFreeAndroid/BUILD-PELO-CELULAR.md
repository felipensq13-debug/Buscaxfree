# Como gerar o APK usando apenas o celular

Este pacote inclui um workflow do GitHub Actions para compilar o projeto na nuvem. Eu não consigo entrar na sua conta do GitHub nem publicar o repositório por você; você precisa fazer estes passos no navegador.

1. Entre em https://github.com/ e crie uma conta ou faça login.
2. Crie um repositório novo chamado `BuscaXFreeAndroid`. Para simplificar, marque-o como **Public** (o GitHub Actions tem limites gratuitos; confirme os termos atuais antes de usar).
3. Envie os arquivos deste ZIP para o repositório, mantendo as pastas e incluindo a pasta `.github/workflows`.
4. Abra a aba **Actions** no repositório. Se solicitado, habilite workflows.
5. Selecione **Build BuscaX Free APK** e toque em **Run workflow** (ou envie um commit para `main`, que também inicia o workflow).
6. Quando terminar com sucesso, abra a execução e baixe o artefato `BuscaXFree-debug-apk` na seção **Artifacts**.
7. Extraia o ZIP do artefato e toque em `app-debug.apk` para instalar. O Android pode pedir autorização para instalar apps dessa origem.

## Importante
- Este é um APK de depuração, não uma versão publicada na Play Store.
- O protótipo abre Google Lens/Yandex e links de busca web. Ele **não** faz reconhecimento facial nem encontra automaticamente perfis do Instagram/TikTok por rosto.
- Nunca compartilhe senha, códigos de autenticação ou fotos privadas. Revise as configurações de visibilidade do repositório antes de enviar arquivos.
