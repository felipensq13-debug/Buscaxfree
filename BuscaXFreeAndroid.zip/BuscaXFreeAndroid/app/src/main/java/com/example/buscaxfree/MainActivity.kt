package com.example.buscaxfree

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ImageSearch
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BuscaXFreeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuscaXFreeApp() {
    val context = LocalContext.current
    var selectedImage by remember { mutableStateOf<Uri?>(null) }
    var showPrivacyNote by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri -> selectedImage = uri }

    val background = Color(0xFF0D1018)
    val panel = Color(0xFF171C29)
    val accent = Color(0xFF7C5CFF)
    val textColor = Color(0xFFF5F5FA)
    val muted = Color(0xFFB5B9C9)

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent,
            background = background,
            surface = panel,
            onBackground = textColor,
            onSurface = textColor
        )
    ) {
        Scaffold(containerColor = background) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("BUSCAX", fontSize = 13.sp, color = accent, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Spacer(Modifier.height(8.dp))
                Text("FREE", fontSize = 38.sp, color = textColor, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Busca reversa de imagens, sem assinatura.",
                    color = muted,
                    fontSize = 15.sp
                )
                Spacer(Modifier.height(24.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = panel),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (selectedImage != null) {
                            AsyncImage(
                                model = selectedImage,
                                contentDescription = "Imagem selecionada",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(260.dp),
                                contentScale = ContentScale.Fit
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(190.dp)
                                    .background(Color(0xFF22283A), RoundedCornerShape(18.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = accent, modifier = Modifier.size(46.dp))
                                    Spacer(Modifier.height(10.dp))
                                    Text("Escolha uma imagem", color = textColor, fontWeight = FontWeight.SemiBold)
                                    Text("A imagem fica no seu aparelho até você abrir uma busca", color = muted, fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { imagePicker.launch("image/*") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (selectedImage == null) "Selecionar foto" else "Trocar foto")
                        }

                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = {
                                if (selectedImage == null) {
                                    Toast.makeText(context, "Selecione uma imagem primeiro.", Toast.LENGTH_SHORT).show()
                                } else {
                                    openUrl(context, "https://lens.google.com/")
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.ImageSearch, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Pesquisar imagem no Google Lens")
                        }

                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                if (selectedImage == null) {
                                    Toast.makeText(context, "Selecione uma imagem primeiro.", Toast.LENGTH_SHORT).show()
                                } else {
                                    openUrl(context, "https://yandex.com/images/")
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.ImageSearch, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Pesquisar imagem no Yandex")
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                Text("Atalhos para páginas públicas", color = textColor, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Essas buscas procuram páginas indexadas na web; não identificam uma pessoa só pelo rosto.",
                    color = muted,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { openUrl(context, "https://www.google.com/search?q=site%3Ainstagram.com") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Instagram") }
                    OutlinedButton(
                        onClick = { openUrl(context, "https://www.google.com/search?q=site%3Atiktok.com") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("TikTok") }
                }

                Spacer(Modifier.height(20.dp))
                TextButton(onClick = { showPrivacyNote = true }) {
                    Text("Privacidade e limitações", color = muted)
                }
                Text("Protótipo gratuito • v0.1", color = Color(0xFF777D91), fontSize = 11.sp)
            }
        }
    }

    if (showPrivacyNote) {
        AlertDialog(
            onDismissRequest = { showPrivacyNote = false },
            title = { Text("Privacidade e limitações") },
            text = {
                Text(
                    "Este protótipo não tem banco de rostos nem reconhece a identidade de pessoas. " +
                    "Os botões abrem serviços externos, que têm suas próprias regras e políticas. " +
                    "Não envie fotos privadas sem autorização e confira os resultados antes de confiar neles."
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyNote = false }) { Text("Entendi") }
            }
        )
    }
}

private fun openUrl(context: android.content.Context, url: String) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(context, "Não foi possível abrir o navegador.", Toast.LENGTH_SHORT).show()
    }
}
